# SFML Hello (macOS + VS Code)

## Quick Start (no CMake, uses `pkg-config`)
1) Install Homebrew if you don't have it:  
   `/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"`
2) Install SFML + pkg-config + clang:  
   `brew install sfml pkg-config`
3) Open this folder in VS Code. When prompted, install the C/C++ extension.
4) Press **⌘⇧B** (Run Build Task) to compile. The output will be `./sfml-hello`.
5) Run it from the VS Code terminal: `./sfml-hello`  
   You should see a window titled **"SFML is installed 🎉"** — take a screenshot for Canvas.

> If you get a font warning, that's fine. The shapes are enough for the screenshot.

## Alternative: CMake route
1) `brew install cmake sfml`
2) In VS Code, install the **CMake Tools** extension.
3) From the command palette: **CMake: Configure**, then **CMake: Build**.
4) Run the resulting binary from the build directory.

## Common macOS notes
- If the window opens and immediately disappears, run from the terminal to see errors.
- On Apple silicon, Homebrew lives at `/opt/homebrew`. `pkg-config` handles flags for you.
- If linking fails, run `pkg-config --cflags --libs sfml-graphics` to verify SFML is visible.
