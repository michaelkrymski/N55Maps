#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/System.hpp>

int main() {
    sf::RenderWindow window(sf::VideoMode(800, 600), "SFML is installed 🎉");
    window.setFramerateLimit(60);

    // Simple demo content
    sf::Font font;
    // Try loading a built-in macOS font path as a convenience; it's okay if this fails
    if (!font.loadFromFile("/System/Library/Fonts/Supplemental/Arial Unicode.ttf")) {
        // fallback: draw only shapes if font not found
    }

    sf::CircleShape circle(100.f);
    circle.setFillColor(sf::Color(150, 200, 255));
    circle.setOutlineThickness(8.f);
    circle.setOutlineColor(sf::Color::Blue);
    circle.setPosition(80.f, 120.f);

    sf::RectangleShape box(sf::Vector2f(260.f, 80.f));
    box.setFillColor(sf::Color(40, 40, 40));
    box.setPosition(300.f, 40.f);

    sf::Text text;
    text.setFont(font);
    text.setString("SFML setup on macOS!");
    text.setCharacterSize(28);
    text.setFillColor(sf::Color::White);
    text.setPosition(310.f, 55.f);

    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) window.close();
            if (event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Escape) window.close();
        }
        window.clear(sf::Color(20, 20, 24));
        window.draw(circle);
        window.draw(box);
        if (font.getInfo().family != "") window.draw(text);
        window.display();
    }
    return 0;
}
